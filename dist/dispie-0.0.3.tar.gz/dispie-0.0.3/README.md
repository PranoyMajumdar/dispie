# Dispie
🚀 A fantastic library created for use with Discord.py

# Install 
Install stable version **(Recommended)**:
```py
python3 -m pip install dispie
```

Install developement version:
```py
python3 -m pip install git+https://github.com/PranoyMajumdar/dispie
```

# Features
Quick overview of the available features.

- [x] Button Paginator
<!-- - [ ] Music (In developementment)
- [ ] Hot Reloader (In developement) -->
